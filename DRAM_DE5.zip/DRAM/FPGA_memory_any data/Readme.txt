Following tutorial all use DE5 Gen2x8 for example
Note that I have change the Qsys and DE5QGen2x8If128.v file to operate at 125MHz,
therefore it should be DE5QGen2x4If128 version!!!
Test: ./testutil 2 4~65536 (It can recieve less than 65536 data)
(No data backward)


Copy riffa to your directory
	cp -r /mnt/ds1515/fpga/riffa_2.2.2/ ./
	/mnt/ds1515/opt/intelFPGA/17.0/quartus/bin/quartus &
	sudo killall jtagd
	sudo /mnt/ds1515/opt/intelFPGA/15.0/quartus/bin/jtagconfig

Copy all the files to the directory
/riffa_2.2.2/source/fpga/altera/de5/DE5QGen2x8If128/prj/
	./DDR3_x2/
	DE5QGen2x8If128.qsf
	DE5QGen2x8If128.qpf

/riffa_2.2.2/source/fpga/altera/de5/DE5QGen2x8If128/ip/
	QSysDE5QGen2x8If128.qsys

/riffa_2.2.2/source/fpga/altera/de5/DE5QGen2x8If128/hdl/
	DE5QGen2x8If128.v

/riffa_2.2.2/source/fpga/altera/de5/DE5QGen2x8If128/constr/
	DE5QGen2x8If128.sdc

/riffa_2.2.2/source/c_c++/linux/x64/
	./sample_app/

/riffa_2.2.2/source/fpga/riffa_hdl/
	bram_wrapper
	chnl_tester
	DRAM_controller







