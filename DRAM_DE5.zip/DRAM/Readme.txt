DE5_v10 確認output可以暫停輸出
		10_3_1: addr:16 4194304筆資料 可以pass
